package com.cg.mra.ui;


import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;



public class MainUI {
	 public static void main(String args[]) throws AccountException{
		 AccountService service=new AccountServiceImpl();
	        Account acc;
	        int ch=0;
	        String mob;
	        Scanner sc=new Scanner(System.in);
	        do{
				        System.out.println("1. Account Balance Enquiry ");
				        System.out.println("2. Recharge Amount");
				        System.out.println("3. Exit");
				        System.out.println("Enter Your Choice");
				        ch=sc.nextInt();
				        switch(ch)
				         {
			        case 1:
			            System.out.println("Enter MobileNo :");
			            mob=sc.next();
			            acc=service.getAccountDetails(mob);
			            if(!service.validateMobNo(mob)){
		                    System.out.println("Mobile No is Invalid");
		                    System.out.println();
		                    break;}
		                
			            if(acc==null){
                            System.err.println("Given Account Id Does NOt Exits");
                            System.out.println();}
                        else{
                            System.out.println("Your Current Balance is Rs. " + acc.getAccountBalance());
                            System.out.println();
                            
                          }
			            break;
			       
						case 2:
				        	System.out.println("Enter MobileNo: ");
				           mob=sc.next();
				            acc=service.getAccountDetails(mob);
				            if(!service.validateMobNo(mob)){
			                    System.out.println("Mobile No is Invalid");
			                    System.out.println();
			                    break;}
			                
				            if(acc==null){
	                            System.err.println("Given Account Id Does NOt Exits");
	                            System.out.println();}
	                        else{
	                        	System.out.println("Enter recharge amount");
	                        	double amt=sc.nextDouble();
	                        	amt=service.rechargeAccount(mob,amt);
	                        	System.out.println("Your Account Recharged Successfully");
	                        	System.out.println("Your Current Balance is Rs. " + acc.getAccountBalance());
	                        	
			                }
			           
				         
	        }

}while(ch!=3);
	        System.out.println("Application closed");
}
}
