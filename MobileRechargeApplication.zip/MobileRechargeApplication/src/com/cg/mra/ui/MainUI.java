package com.cg.mra.ui;


import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.NumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;




public class MainUI {
	 public static void main(String args[]) throws AccountException{
		 AccountService service=new AccountServiceImpl();
	        Account acc=null;
	        int ch=0;
	        String mob;
	        Scanner sc=new Scanner(System.in);
	        do{
				        System.out.println("1. Account Balance Enquiry ");
				        System.out.println("2. Recharge Amount");
				        System.out.println("3. Exit");
				        System.out.println("Enter Your Choice");
				        ch=sc.nextInt();
				        switch(ch)
				         {
			        case 1:
			            System.out.println("Enter MobileNo :");
			            mob=sc.next();
			           
			            try{
					           if(!service.validateMobNo(mob))
								{
								throw new NumberException();
								}
					            acc=service.getAccountDetails(mob);
					            System.out.println("Your Current Balance is Rs. " + acc.getAccountBalance());
					           }
					           catch(NumberException e)
					           {
					        	   System.out.println(e);
					        	   break;
					           }
				                catch(Exception e)
					           {
				                	System.out.println("Given Account Id Does NOt Exits");
					           }
                        
                            
                            System.out.println();
                            
                          
			            break;
			       
						case 2:
				        	System.out.println("Enter MobileNo: ");
				           mob=sc.next();
				           try{
				           if(!service.validateMobNo(mob))
							{
							throw new NumberException();
							}
				            acc=service.getAccountDetails(mob);
				           }
				           catch(NumberException e)
				           {
				        	   System.out.println(e);
				        	   break;
				           }
			                catch(Exception e)
				           {
			                	System.out.println("Given Account Id Does NOt Exits");
				           }
			                    
			                
				            
	                        
	                        	System.out.println("Enter recharge amount");
	                        	double amt=sc.nextDouble();
	                        	amt=service.rechargeAccount(mob,amt);
	                        	System.out.println("Your Account Recharged Successfully");
	                        	System.out.println("Your Current Balance is Rs. " + acc.getAccountBalance());
	                        	
			                }
			           
				         
	        

}while(ch!=3);
	        System.out.println("Application closed");
}
}
