package com.cg.mra.service;


import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.NumberException;

public interface AccountService {
	public Account getAccountDetails(String mobileNo) throws NumberException;
	public double rechargeAccount(String mobileNo,double rechargeAmount) ;
	public boolean validateMobNo(String mob);

}
