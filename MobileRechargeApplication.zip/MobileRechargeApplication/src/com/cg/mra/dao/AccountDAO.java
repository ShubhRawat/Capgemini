package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.NumberException;



public interface AccountDAO {
	public Account getAccountDetails(String mobileNo) throws NumberException;
	public double rechargeAccount(String mobileNo,double rechargeAmount);

}
