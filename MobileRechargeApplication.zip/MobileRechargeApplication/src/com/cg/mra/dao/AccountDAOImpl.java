package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;




import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.NumberException;

public class AccountDAOImpl implements AccountDAO{
	
	Map<String,Account> accountEntry;
	public AccountDAOImpl(){
		accountEntry=new HashMap<>();
		accountEntry.put("9010210131",new Account("Prepaid","Vaishali",200));
		accountEntry.put("9823920123",new Account("Prepaid","Megha",453));
		accountEntry.put("9932012345",new Account("Prepaid","Vikas",631));
		accountEntry.put("7017742790",new Account("Prepaid","Anju",521));
		accountEntry.put("7895155737",new Account("Prepaid","Tushar",632));
	}

	//fetching accountDetails for provided MobileNo
	@Override
	public Account getAccountDetails(String mobileNo) throws NumberException {
		Account acc= accountEntry.get(mobileNo);
		return acc;
	}

	//updating the final amount of balance
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount)  {
		
		Account acc=accountEntry.get(mobileNo);
		acc.accountBalance=acc.getAccountBalance()+rechargeAmount;
		return acc.getAccountBalance();
	}

}
