package com.cg.mra.test;

public class TestClass {

}
