package com.cg.mra.exception;

public class NumberException extends Exception{

	public NumberException(){
		super("Invalid Phone Number\n"
				+ "Mobile Number should be of 10 digits and does not contain alphabets");
		
	}
}
