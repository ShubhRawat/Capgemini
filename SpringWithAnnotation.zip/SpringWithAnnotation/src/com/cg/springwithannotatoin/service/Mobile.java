package com.cg.springwithannotatoin.service;

import java.util.List;

import org.springframework.stereotype.Component;




@Component("mob")//<bean id="" class="">
public class Mobile {

	int mobileId;
	String mobileName;
	double mobilePrice;
	

	public void printMobileDetails(){
		//System.out.println("Id is "+mobileId+" Name is "+mobileName+" Price Is "+mobilePrice);
		
		System.out.println("mobile data");
	}
}
	