package com.cg.springwithannotatoin.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springwithannotatoin.service.Mobile;



public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=
				new ClassPathXmlApplicationContext("spring.xml");
		Mobile mobile=(Mobile) app.getBean("mob");
		mobile.printMobileDetails();
	}

}
