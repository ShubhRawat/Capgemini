package com.cg.lh.dto;

import java.util.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_leave_details")
public class Leave {
	
	@Id
	@Column(name="leave_id")
	Integer leave_id;
	
	@Column(name="empid")
	Integer empid;
	
	@Column(name="start_date")
	Date start_date;
	@Column(name="end_date")
	Date end_date;
	@Column(name="description")
	String description;
	
	@Column(name="leaves_applied")
	Integer leaves_applied;

	public Integer getLeave_id() {
		return leave_id;
	}

	public void setLeave_id(Integer leave_id) {
		this.leave_id = leave_id;
	}

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public Leave(Integer leave_id, Integer empid, Date start_date,
			Date end_date, String description, Integer leaves_applied) {
		super();
		this.leave_id = leave_id;
		this.empid = empid;
		this.start_date = start_date;
		this.end_date = end_date;
		this.description = description;
		this.leaves_applied = leaves_applied;
	}

	public Leave() {
		super();
	}

	@Override
	public String toString() {
		return "Leave [leave_id=" + leave_id + ", empid=" + empid
				+ ", start_date=" + start_date + ", end_date=" + end_date
				+ ", description=" + description + ", leaves_applied="
				+ leaves_applied + "]";
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getLeaves_applied() {
		return leaves_applied;
	}

	public void setLeaves_applied(Integer leaves_applied) {
		this.leaves_applied = leaves_applied;
	}
}
	
	
