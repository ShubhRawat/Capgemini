package com.cg.lh.service;

import java.util.List;

import com.cg.lh.dto.Leave;




public interface ILeaveService {

	public Leave searchleave(int empId);
}
