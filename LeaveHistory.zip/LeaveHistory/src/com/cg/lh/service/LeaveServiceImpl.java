package com.cg.lh.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lh.dao.ILeaveDAO;
import com.cg.lh.dto.Leave;

@Service("leaveservice")
@Transactional
public class LeaveServiceImpl implements ILeaveService {
	
	@Autowired
	ILeaveDAO leavedao;
	
	
	

	@Override
	public Leave searchleave(int empId) {
		// TODO Auto-generated method stub
		return leavedao.searchLeave(empId);
	}

	
}
