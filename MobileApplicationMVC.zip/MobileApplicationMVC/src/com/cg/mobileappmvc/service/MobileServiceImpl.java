package com.cg.mobileappmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mobileappmvc.dao.IMobileDAO;
import com.cg.mobileappmvc.dto.Mobile;

@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements IMobileService{

	@Autowired
	IMobileDAO mobiledao;
	@Override
	public void addMobile(Mobile mobile) {
		mobiledao.addMobile(mobile);
		
	}

	@Override
	public List<Mobile> showAllMobile() {
		
		return null;
	}

	@Override
	public void deleteMobile(int mobId) {
		
		
	}

	@Override
	public Mobile searchMobile(int mobId) {
		
		return null;
	}

}
