//Spring One
package com.cg.springone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springone.service.Mobile;
import com.cg.springone.service.Shape;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext app=
				new ClassPathXmlApplicationContext("spring.xml");
		
		/*Shape sp=(Shape) app.getBean("tri");
		sp.getShape();*/
		
		Mobile mobile=(Mobile) app.getBean("mob");
		//mobile.setMobId(10001);
		//mobile.setMobName("LG");
		mobile.getAllDetail();
	}

}
