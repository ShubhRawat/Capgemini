//Spring One

package com.cg.springone.service;

public class Circle implements Shape {

	String radius;//instance variable
	
	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("IN Circle....."+radius);
	}

	public String getRadius() {
		return radius;
	}

	public void setRadius(String radius) {
		this.radius = radius;
	}

}
