//Spring One

package com.cg.springone.service;

public class Triangle implements Shape {

	String sides;//instance variable
	
	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("In Triangle...."+sides);
	}

	public String getSides() {
		return sides;
	}

	public void setSides(String sides) {
		this.sides = sides;
	}

}
