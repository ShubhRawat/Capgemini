package com.cg.springautowiring.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springautowiring.service.MobileServiceImpl;


public class MyApplicationtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=
				new ClassPathXmlApplicationContext("spring.xml");
		MobileServiceImpl mob=(MobileServiceImpl) app.getBean("mobileservice");
		mob.getAllMobile();
		
	}

}
