package com.cg.springautowiring.dao;

public interface IMobileDAO {
	
	public void getAllDaoMobile();
	public void getSBUDetails();

}
