package com.cg.springautowiring.dao;

import org.springframework.stereotype.Repository;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDAO {

	@Override
	public void getAllDaoMobile() {
		// TODO Auto-generated method stub
		System.out.println("in dao mobile");
	}

	@Override
	public void getSBUDetails() {
		// TODO Auto-generated method stub
		
	}

}
