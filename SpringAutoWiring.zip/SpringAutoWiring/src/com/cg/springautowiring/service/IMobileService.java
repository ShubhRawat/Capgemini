package com.cg.springautowiring.service;

public interface IMobileService {
	
	public void getAllMobile();

}
