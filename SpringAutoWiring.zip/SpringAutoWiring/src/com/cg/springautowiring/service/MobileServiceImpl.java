package com.cg.springautowiring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springautowiring.dao.IMobileDAO;


@Service("mobileservice")
public class MobileServiceImpl implements IMobileService{

	@Autowired
	IMobileDAO mobiledao;
	@Override
	public void getAllMobile() {
		System.out.println("IN Service");
		mobiledao.getAllDaoMobile();
		
	}

}
