package com.cg.ss.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ScheduledSessions")
public class Session {
	
	@Id
	@Column(name="id")
	//@NotNull(message="Session Id cannot be empty")
	Integer sessionId;
	@Column(name="name")
	//@NotEmpty(message="Name cannot be empty")
	String sessionName;
	@Column(name="duration")
	Integer sessionDuration;
	@Column(name="faculty")
	String faculty;
	@Column(name="mode1")
	String mode1;
	
	@Override
	public String toString() {
		return "Session [sessionId=" + sessionId + ", sessionName="
				+ sessionName + ", sessionDuration=" + sessionDuration
				+ ", faculty=" + faculty + ", mode1=" + mode1 + "]";
	}
	public Session(Integer sessionId, String sessionName,
			Integer sessionDuration, String faculty, String mode1) {
		super();
		this.sessionId = sessionId;
		this.sessionName = sessionName;
		this.sessionDuration = sessionDuration;
		this.faculty = faculty;
		this.mode1 = mode1;
	}
	public Session() {
		super();
	}
	public Integer getSessionId() {
		return sessionId;
	}
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public Integer getSessionDuration() {
		return sessionDuration;
	}
	public void setSessionDuration(Integer sessionDuration) {
		this.sessionDuration = sessionDuration;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getMode1() {
		return mode1;
	}
	public void setMode1(String mode1) {
		this.mode1 = mode1;
	}
}
