package com.cg.ss.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ss.dao.ISessionDAO;
import com.cg.ss.dto.Session;

@Service("sessionservice")
@Transactional
public class SessionServiceImpl implements ISessionService {
	
	@Autowired
	ISessionDAO sessiondao;
	
	/*
	 * Passing the showAllSession control to DAO Layer
	 * */
	@Override
	public List<Session> showAllSession() {
		// TODO Auto-generated method stub
		return sessiondao.showAllSession();//return fetched data passed by DAO
	}

	
}
