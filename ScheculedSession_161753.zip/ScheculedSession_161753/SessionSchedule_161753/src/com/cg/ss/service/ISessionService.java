package com.cg.ss.service;

import java.util.List;

import com.cg.ss.dto.Session;



public interface ISessionService {

	public List<Session> showAllSession();
}
