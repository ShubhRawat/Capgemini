package com.cg.ss.dao;

import java.util.List;

import com.cg.ss.dto.Session;

public interface ISessionDAO {

	public List<Session> showAllSession();
}
