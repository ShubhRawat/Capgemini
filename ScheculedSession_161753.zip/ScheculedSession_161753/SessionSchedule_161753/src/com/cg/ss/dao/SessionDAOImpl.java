package com.cg.ss.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;



import com.cg.ss.dto.Session;

@Repository("sessiondao")
public class SessionDAOImpl implements ISessionDAO {

	@PersistenceContext
	EntityManager  em;
	
	@Override
	public List<Session> showAllSession() {
		
		Query query=em.createQuery("FROM Session");//Fetching all the data from database
		List<Session>myAll=query.getResultList();
		
		return myAll;//Return fetched data
	}

}
