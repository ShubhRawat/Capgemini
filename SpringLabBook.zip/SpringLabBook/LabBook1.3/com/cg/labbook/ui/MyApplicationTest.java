package com.cg.labbook.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.labbook.service.EmployeeServiceImpl;






public class MyApplicationTest {
	
	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring.xml");
		
		EmployeeServiceImpl emp=(EmployeeServiceImpl) app.getBean("employeeservice");
		emp.getAllEmployeeDetails();
		//emp.getSBUDetails();
	}

}