package com.cg.labbook.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.labbook.dto.Employee;



@Repository("employeedao")
public class EmployeeDaoImpl implements EmployeeDAO{

	@Autowired
	Employee employee;

//Employee employee = new Employee();
public EmployeeDaoImpl() {
	// TODO Auto-generated constructor stub
	
}
 	

	@Override
	public void getSBUDetails() {
		// TODO Auto-generated method stub
		//System.out.println("sbuDetails=SBU [sbuCode="+sbuId+", sbuHead="+sbuHead+", sbuName="+sbuName+"] ]");
	}
	@Override
	public void getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee Details:");
		System.out.println("-------------------------");
		System.out.println("empId="+ employee.getEmployeeId3()+
				", empName=" +employee.getEmployeeName3()+", empSalary="+employee.getSalary3());
	}

}
