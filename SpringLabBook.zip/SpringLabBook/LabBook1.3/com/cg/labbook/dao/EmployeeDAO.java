package com.cg.labbook.dao;

public interface EmployeeDAO {
	public void getAllEmployeeDetails();
	public void getSBUDetails();
}
