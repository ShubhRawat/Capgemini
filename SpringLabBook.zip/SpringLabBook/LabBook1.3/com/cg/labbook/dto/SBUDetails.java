package com.cg.labbook.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;

public class SBUDetails {
    
	@Value("PSU-CB")
	String sbuCode;
	@Value("Product Engg Services")
	String sbuName;
	@Value("Ankita")
	String sbuHead;
	

	public SBUDetails() {
		super();
	}

	public String getSbuCode() {
		return sbuCode;
	}

	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	
}
