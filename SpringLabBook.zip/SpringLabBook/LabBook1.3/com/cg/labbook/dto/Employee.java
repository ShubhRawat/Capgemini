package com.cg.labbook.dto;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component ("Employee")
public class Employee {
@Value("1009")
    int employeeId3;
@Value("Shubham")
	String employeeName3;
@Value("120000.00")
	double salary3;


	
	public int getEmployeeId3() {
		return employeeId3;
	}
	public void setEmployeeId3(int employeeId3) {
		this.employeeId3 = employeeId3;
	}
	public String getEmployeeName3() {
		return employeeName3;
	}
	public void setEmployeeName3(String employeeName3) {
		this.employeeName3 = employeeName3;
	}
	public double getSalary3() {
		return salary3;
	}
	public void setSalary3(double salary3) {
		this.salary3 = salary3;
	}
	
	
}
