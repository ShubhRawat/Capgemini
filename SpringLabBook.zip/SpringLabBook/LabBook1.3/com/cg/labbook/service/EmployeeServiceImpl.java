package com.cg.labbook.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.labbook.dao.EmployeeDAO;



@Service("employeeservice")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO employeedao;
	
	
	@Override
	public void getAllEmployeeDetails() {
		//System.out.println("IN Service");
		employeedao.getAllEmployeeDetails();
		
	}
	@Override
	public void getSBUDetails() {
		
		employeedao.getSBUDetails();
	}

}
