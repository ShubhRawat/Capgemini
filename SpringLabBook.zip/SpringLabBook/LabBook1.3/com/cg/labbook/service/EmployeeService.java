package com.cg.labbook.service;

public interface EmployeeService {

		public void getAllEmployeeDetails();
		public void getSBUDetails();
	}


