package com.cg.labbook.service;
public class SBUDetails {

	String sbuId;
	String sbuName;
	String sbuHead;
	
	public SBUDetails() {
		super();
	}
	
	
	


	
	public SBUDetails(String sbuId, String sbuName, String sbuHead) {
		
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}






	public String getSbuId() {
		return sbuId;
	}






	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}






	public String getSbuName() {
		return sbuName;
	}






	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}






	public String getSbuHead() {
		return sbuHead;
	}






	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
}