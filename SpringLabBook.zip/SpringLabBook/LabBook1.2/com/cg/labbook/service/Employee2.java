package com.cg.labbook.service;

public class Employee2 extends SBUDetails{

	int employeeId2;
	String employeeName2;
	double salary2;
	String businessUnit2;
	int age2;
	
	public int getEmployeeId2() {
		return employeeId2;
	}



	public void setEmployeeId2(int employeeId2) {
		this.employeeId2 = employeeId2;
	}



	public String getEmployeeName2() {
		return employeeName2;
	}



	public void setEmployeeName2(String employeeName2) {
		this.employeeName2 = employeeName2;
	}



	public double getSalary2() {
		return salary2;
	}



	public void setSalary2(double salary2) {
		this.salary2 = salary2;
	}



	public String getBusinessUnit2() {
		return businessUnit2;
	}



	public void setBusinessUnit2(String businessUnit2) {
		this.businessUnit2 = businessUnit2;
	}



	public int getAge2() {
		return age2;
	}



	public void setAge2(int age2) {
		this.age2 = age2;
	}




	
	
	
	public void display(){
		System.out.println("Employee Details:");
		System.out.println("-------------------------");
		System.out.println("Employee [ empAge="+employeeId2+", empId="+employeeId2+
				", empName=" +employeeName2+", empSalary="+salary2+
				"\n"+"sbuDetails=SBU [sbuCode="+sbuId+", sbuHead="+sbuHead+", sbuName="+sbuName+"] ]"); 
		
	}




	
}
