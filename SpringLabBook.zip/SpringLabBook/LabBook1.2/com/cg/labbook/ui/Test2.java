package com.cg.labbook.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.labbook.service.Employee2;

public class Test2 {
	
	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring.xml");
		
		Employee2 emp=(Employee2) app.getBean("emp2");
		emp.display();
		//emp.getSBUDetails();
	}

}