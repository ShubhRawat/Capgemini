package com.cg.labbook.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.labbook.service.Employee;

public class Test {
	
	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring.xml");
		
		Employee emp=(Employee) app.getBean("emp");
		emp.display();
		
	}

}