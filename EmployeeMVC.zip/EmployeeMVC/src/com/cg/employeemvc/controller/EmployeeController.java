package com.cg.employeemvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class EmployeeController {
	@RequestMapping(value="/home")
	public String getAllEmployee()
	{
		return "Welcome";
	}
}