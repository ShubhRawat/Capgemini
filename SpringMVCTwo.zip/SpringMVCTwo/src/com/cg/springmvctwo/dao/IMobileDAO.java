package com.cg.springmvctwo.dao;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;



public interface IMobileDAO {

	
	public List<Mobile> showAllMobile();
	
}
