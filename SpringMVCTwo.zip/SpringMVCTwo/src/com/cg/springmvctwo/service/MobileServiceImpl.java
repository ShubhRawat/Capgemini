package com.cg.springmvctwo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvctwo.dao.IMobileDAO;
import com.cg.springmvctwo.dto.Mobile;



@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements IMobileService{

	@Autowired
	IMobileDAO mobiledao;
	
		@Override
	public List<Mobile> showAllMobile() {
		
		return mobiledao.showAllMobile();
	}


}
