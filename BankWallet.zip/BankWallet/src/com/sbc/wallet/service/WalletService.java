package com.sbc.wallet.service;

import com.sbc.wallet.dto.Customer;
import com.sbc.wallet.exception.WalletException;
import com.sbc.wallet.exception.InvalidAmount;
import com.sbc.wallet.exception.InvalidPhoneNumber;

public interface WalletService {
	
	public Customer createAccount(Customer cus);
	public double showBalance (String mobileno) throws InvalidPhoneNumber;
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount) throws WalletException;
	public Customer depositAmount (String mobileNo, double amount ) throws InvalidPhoneNumber, InvalidAmount;
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException;
	public boolean validateUserName(String name);
	public boolean validatePhoneNumber(String mobNo);
	public boolean validateRecipientMobNo(String RecipientMobNo);
	public boolean validateAmount(double amt);
	public boolean validateAll(Customer cus);
	
}
