package com.sbc.wallet.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sbc.wallet.dao.WalletDAO;
import com.sbc.wallet.dao.WalletDAOImpl;
import com.sbc.wallet.dto.Customer;
import com.sbc.wallet.exception.WalletException;
import com.sbc.wallet.exception.InvalidAmount;
import com.sbc.wallet.exception.InvalidPhoneNumber;

public class WalletServiceImpl implements WalletService{
	
	WalletDAO dao;
	
	public WalletServiceImpl() {
		dao = new WalletDAOImpl();	
	}
	
	@Override
	public boolean validateAll(Customer cus){
		
		boolean b = false;

		if(validateUserName(cus.getCustomerName()) == true && validatePhoneNumber(cus.getMobileNumber()) == true && validateAmount(cus.getAmount()) == true)
			b = true;
		return b;
	}
	
	@Override
	public boolean validateUserName(String name){
		
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{2,30}");
		Matcher mat = p.matcher(name);
		boolean b = mat.matches();
		
		return b;
	}
	
	@Override
	public boolean validatePhoneNumber(String mobileNo){
		
		Pattern pat = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher mat = pat.matcher(mobileNo);
		
		return mat.matches();
	}
	
	@Override
	public boolean validateAmount(double amt){
		
		Pattern pat = Pattern.compile("[1-9]{1}[0-9.]{0,9}");
		Matcher mat = pat.matcher(String.valueOf(amt));
		
		return mat.matches();
	}
	
	@Override
	public boolean validateRecipientMobNo(String RecipientMobNo){
		
		Pattern pat = Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher mat = pat.matcher(RecipientMobNo);
		
		return mat.matches();
	}

	@Override
	public Customer createAccount(Customer c) {
		// TODO Auto-generated method stub
		return dao.createAccount(c);
	}

	@Override
	public double showBalance(String mobileno) throws InvalidPhoneNumber {
		// TODO Auto-generated method stub
		double bal = dao.showBalance(mobileno);
		return bal;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String RecipientMobNo, double amount) throws WalletException {
		// TODO Auto-generated method stub
		Customer c = dao.fundTransfer(sourceMobileNo, RecipientMobNo, amount);
		return c;
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) throws InvalidPhoneNumber, InvalidAmount {
		// TODO Auto-generated method stub
		Customer c = dao.depositAmount(mobileNo, amount);
		return c;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException {
		// TODO Auto-generated method stub
		Customer c = dao.withdrawAmount(mobileNo, amount);
		return c;
	}

}
