package com.sbc.wallet.exception;

public class InvalidPhoneNumber extends Exception {
	public InvalidPhoneNumber() {
		// TODO Auto-generated constructor stub
		super("Invalid Phone Number\n"
				+ "Mobile Number should be of 10 digits and does not contain alphabets");
				
	}
}
