package com.sbc.wallet.exception;

public class InvalidAmount extends Exception{
	public InvalidAmount() {
			super("Invalid Amount"
					+ "Amount should be greater than 0)");
	}
}
