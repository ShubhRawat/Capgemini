package com.sbc.wallet.exception;

@SuppressWarnings("serial")
public class WalletException extends Exception {

	public WalletException(String message) {
		super(message);
	}

}
