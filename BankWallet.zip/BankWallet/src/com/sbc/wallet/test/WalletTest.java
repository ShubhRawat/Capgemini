package com.sbc.wallet.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.sbc.wallet.service.WalletServiceImpl;

public class WalletTest {
	
	@Test
	public void ValidateNameTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validateUserName("Shubham"));
	}
	
//	@Test (expected = InvalidNameFormat.class)
//	public void ValidateUserNameV1(){
//		WalletServiceImpl bs = new WalletServiceImpl();
		
//	}
	
	@Test
	public void ValidatePhonNumberTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validatePhoneNumber("7895155737"));
	}
	
	@Test
	public void ValidatePhoneNumber(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validatePhoneNumber("784551254"));
		assertEquals(false, bs.validatePhoneNumber("7017742790"));
		assertEquals(false, bs.validatePhoneNumber("802502"));
		assertEquals(false, bs.validatePhoneNumber("shubh"));
		assertEquals(false, bs.validatePhoneNumber("%$#"));
	}
	
	@Test 
	public void ValidateNameV2(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validateUserName("Shubh1234"));
		assertEquals(false, bs.validateUserName("Shubh@1234"));
		assertEquals(false, bs.validateUserName("276915"));
		assertEquals(false, bs.validateUserName("rawat"));
	}
	
	@Test
	public void ValidateAmountTrue(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(true, bs.validateAmount(200));
	}
	
	@Test 
	public void ValidateAmount(){
		WalletServiceImpl bs = new WalletServiceImpl();
		assertEquals(false, bs.validateAmount(0));
		assertEquals(false, bs.validateAmount(-600));
	}

}
