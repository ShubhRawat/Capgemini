package com.sbc.wallet.dao;

import com.sbc.wallet.dto.Customer;
import com.sbc.wallet.exception.WalletException;

public interface WalletDAO {
	
	public Customer createAccount(Customer c);
	public double showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String recipientMobileNo, double amount) throws WalletException;
	public Customer depositAmount (String mobileNo, double amount );
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException;

}
