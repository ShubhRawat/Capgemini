package com.sbc.wallet.dao;

import java.sql.Connection;
import java.util.Map;
import java.util.Set;

import com.sbc.wallet.dto.Customer;
import com.sbc.wallet.exception.WalletException;

public class WalletDAOImpl implements WalletDAO {
	
	Map<String, Customer> map;

	
	public WalletDAOImpl() {
		map = DataContainer.createCollection();

	}
	
   //creating new account for user
	@Override
	public Customer createAccount(Customer cust) {

		map.put(cust.getMobileNumber(), cust);
		return cust;
	}

	//displaying the current balance
	@Override
	public double showBalance(String mobileno) {

		Customer cusShow = map.get(mobileno);
		double bal = cusShow.getAmount();
		return bal;
	}

	
	//Transferring fund from source account to recipient account
	@Override
	public Customer fundTransfer(String sourceMobileNo, String recipientMobileNo, double amount) throws WalletException {

		Customer cusfundsource = map.get(sourceMobileNo);
		Customer cusfundrecipient = map.get(recipientMobileNo);
		if((cusfundsource.getAmount()-amount) >= 0){
			cusfundrecipient.setAmount(cusfundrecipient.getAmount()+amount);
			map.put(recipientMobileNo, cusfundrecipient);
			cusfundsource.setAmount(cusfundsource.getAmount()-amount);
			map.put(sourceMobileNo, cusfundsource);
			
			
		}
		else
			throw new WalletException("The overall balance must be greater than zero...");
		

		return cusfundsource;
	}

	//deposit amount in  account
	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		
		Customer cusDep = map.get(mobileNo);
		cusDep.setAmount(cusDep.getAmount()+amount);
		map.put(mobileNo, cusDep);
		
		return cusDep;
	}

	//withdrawing amount from account
	@Override
	public Customer withdrawAmount(String mobileNo, double amount) throws WalletException {
		
		Customer cusDep = map.get(mobileNo);
		if((cusDep.getAmount()-amount) >= 0){
			cusDep.setAmount(cusDep.getAmount()-amount);
			map.put(mobileNo, cusDep);
		}
		else
			throw new WalletException("Unable to withdraw money...\n"
					+ "Make sure the balance is greater than or equal to zero");
		return cusDep;
	}

}
