package com.sbc.wallet.ui;

/**
 *  @author Shubham Rawat
 *
 */
import java.util.Scanner;

import com.sbc.wallet.dto.Customer;
import com.sbc.wallet.exception.WalletException;
import com.sbc.wallet.exception.InvalidAmount;
import com.sbc.wallet.exception.InvalidPhoneNumber;
import com.sbc.wallet.exception.NameException;
import com.sbc.wallet.service.WalletService;
import com.sbc.wallet.service.WalletServiceImpl;

public class ui {

	public static void main(String[] args) throws InvalidPhoneNumber, InvalidAmount, NameException, WalletException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		WalletService service = null;
		String name="",mobNo="";
		double amt=0.0;
		int ch;
		do{
			
			System.out.println("1. Account...");
			System.out.println("2. Show Balance...");
			System.out.println("3. Withdraw Amount...");
			System.out.println("4. Deposit Amount...");
			System.out.println("5. Fund Transfer...");
			System.out.println("6. Exit...");
			ch = sc.nextInt();
			
			switch (ch) {
			case 1:
                
							service = new WalletServiceImpl();
							System.out.println("Enter Customer Name: ");
								 name = sc.next();
								
							try
							{
									if(!service.validateUserName(name))
									{
										throw new NameException();
									}
							}
							catch(NameException e)
							{
								System.out.println(e);
								
							}
                  
								System.out.println("Enter Mobile Number: ");
								 mobNo = sc.next();
								
								try{
										if(!service.validatePhoneNumber(mobNo))
										{
											throw new InvalidPhoneNumber();
										}
								}
								catch(InvalidPhoneNumber e)
								{
									System.out.println(e);
								}
                  
								System.out.println("Enter Initial Amount: ");
								amt = sc.nextDouble();
								
								try{
										if(!service.validateAmount(amt))
										{
											throw new InvalidAmount();
										}
								}
								catch(InvalidAmount e)
								{
									System.out.println(e);
								}
                   
				
				try{
						Customer cus = new Customer(name, mobNo, amt);
						Customer cus1 = null;
						if(service.validateAll(cus))
							cus1 = service.createAccount(cus);
						else
							throw new WalletException("Invalid details...");
						System.out.println(cus1);
						System.out.println("Account Created Successfully for "+cus1.getCustomerName()+" with "
								+ "Mobile Number "+cus1.getMobileNumber());
						break;
				}
				catch(WalletException e)
				{
					System.out.println(e);
				}
			
                 
                break;
				
				
			
			case 2:
				
				System.out.println("Enter Registered mobile number: ");
				String mobNoReg = sc.next();
				try
				{
					if(!service.validatePhoneNumber(mobNoReg))
					{
					throw new InvalidPhoneNumber();
					}
				
				
					double bal = service.showBalance(mobNoReg);
					System.out.println("Available balance for the mobile number "+mobNoReg+" is " +bal);
				}
				catch(Exception e)
				{
					System.out.println("Phone Number is not registered");
				}
				break;
			
			case 3:
				System.out.println("Enter your mobile number: ");
				String mobNoWithDraw= sc.next();
				try{
						if(!service.validatePhoneNumber(mobNoWithDraw))
						{
							throw new InvalidPhoneNumber();
						}
			
						System.out.println("Enter amount that to be withdrawn: ");
						double amtWithDraw = sc.nextDouble();
						if(!service.validateAmount(amtWithDraw))
						{
							throw new InvalidAmount();
						}
				
						service = new WalletServiceImpl();
						Customer cusWD= service.withdrawAmount(mobNoWithDraw, amtWithDraw);
				
						System.out.println("Your current balance is Rs. "+cusWD.getAmount());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				
				break;
			
			case 4:
				
				System.out.println("Enter your mobile number: ");
				String mobNoDeposit = sc.next();
				if(!service.validatePhoneNumber(mobNoDeposit)){
					throw new InvalidPhoneNumber();
				}
				System.out.println("Enter amount that to be deposited: ");
				double amtDeposit = sc.nextDouble();
				if(!service.validateAmount(amtDeposit)){
					throw new InvalidAmount();
				}
				
				service = new WalletServiceImpl();
				Customer cusDep = service.depositAmount(mobNoDeposit, amtDeposit);
				
				System.out.println("Your current balance is Rs."+cusDep.getAmount());
//				System.out.println(cDep);
				
				break;
			
			case 5:
				
				
				System.out.println("Enter your mobile number: ");
				String sourceMobileNo = sc.next();
				try{
				if(!service.validatePhoneNumber(sourceMobileNo))
					{
						throw new InvalidPhoneNumber();
					}
				double bal = service.showBalance(sourceMobileNo);
				}
				catch(Exception e)
				{System.out.println("Phone Number is not registered");
				break;}
				
				
				System.out.println("Enter recipient's mobile number: ");//check whether mobile number exists in the Collection.
				String recipientMobileNo = sc.next();
				try{
				if(!service.validatePhoneNumber(recipientMobileNo))
				{
					throw new InvalidPhoneNumber();
					
				}
				double bal = service.showBalance(recipientMobileNo);
				}
				catch(Exception e)
				{
					System.out.println("Phone Number is not registered");
					break;
				}
				
				System.out.println("Enter the amount that to be transfered: ");
				double amount = sc.nextDouble();
				if(!service.validateAmount(amount)){
					throw new InvalidAmount();
				}
				
				service = new WalletServiceImpl();
				Customer totalAmount = null;
				totalAmount = service.fundTransfer(sourceMobileNo, recipientMobileNo, amount);
				System.out.println("Successfully transfered Rs."+amount+" to "+recipientMobileNo);
				System.out.println("Available balance is Rs. "+totalAmount.getAmount());
					
				
				break;
			
		
			}
			
		}while(ch != 6);
		
			
		sc.close();
	}

}
